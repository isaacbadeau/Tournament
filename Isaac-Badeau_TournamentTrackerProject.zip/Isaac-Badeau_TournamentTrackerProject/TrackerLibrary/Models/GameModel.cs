﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackerLibrary.Models
{
    public class GameModel
    {
        public string StreetFighter { get; set; }
        public string SmashBros { get; set; }
        public string MortalKombat { get; set; }
    }
}
